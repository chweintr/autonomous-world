// Agent Worlds — Studio interactivity
(() => {
  const $ = (sel, el = document) => el.querySelector(sel);
  const $$ = (sel, el = document) => [...el.querySelectorAll(sel)];
  const on = (el, ev, fn) => el.addEventListener(ev, fn);

  // Theme
  const theme = $('#theme');
  on(theme, 'change', () => {
    document.documentElement.setAttribute('data-theme', theme.value);
    toast(`Theme: ${theme.options[theme.selectedIndex].text}`);
  });

  // Fullscreen
  on($('#btnFullscreen'), 'click', () => {
    if (!document.fullscreenElement) document.documentElement.requestFullscreen().catch(()=>{});
    else document.exitFullscreen().catch(()=>{});
  });

  // LLM toggle
  const useLLM = $('#useLLM');
  const apiKeyWrap = $('#apiKeyWrap');
  on(useLLM, 'change', () => {
    apiKeyWrap.classList.toggle('hidden', !useLLM.checked);
  });

  // Run / Save / Reset — stubbed hooks
  on($('#run'), 'click', () => {
    $('#statusVal').textContent = 'running';
    pulseFPS();
    toast('Simulation started');
    // TODO: hook into your simulation runner
    // dispatchEvent(new CustomEvent('sim:run', { detail: collectScenario() }));
  });
  on($('#save'), 'click', () => {
    // TODO: persist to storage or your backend
    toast('Session saved');
    // dispatchEvent(new CustomEvent('sim:save', { detail: collectScenario() }));
  });
  on($('#reset'), 'click', () => {
    $('#statusVal').textContent = 'paused';
    toast('Reset');
    // dispatchEvent(new CustomEvent('sim:reset'));
  });

  // Generate Report — reads notes and composes a tiny summary
  on($('#genReport'), 'click', () => {
    const notes = $$('#notes .note');
    const places = {};
    notes.forEach(n => {
      const pill = $('.pill', n)?.textContent || '';
      const loc = pill.split('·')[0].trim();
      places[loc] = (places[loc] || 0) + 1;
    });
    const lines = [
      '# EMERGENCE PATTERNS',
      '',
      '## Location Tendencies',
      ...Object.entries(places).map(([loc, c]) => `- ${loc.toLowerCase().replace(/\s+/g,'_')}: ${c} visit${c>1?'s':''}`),
      '',
      '## Recurring Pairings',
      'No significant recurring pairings yet.',
      '',
      '## Location Atmospheres',
      '- loc_burial_ground: Tends toward uncertain (2/2)',
      '',
      '## Emergent/Unexpected Events: 0'
    ];
    $('#reportBody').innerHTML = `<pre>${lines.join('\n')}</pre>`;
    toast('Report generated');
  });

  // Time-of-day slider -> decorative temperature hue shift
  on($('#timeOfDay'), 'input', (e) => {
    const v = +e.target.value;
    const chips = $$('.chip');
    chips.forEach(c => c.style.filter = `hue-rotate(${(v/24)*120 - 30}deg)`);
  });

  // FPS sampler (cosmetic)
  let last = performance.now();
  let frames = 0;
  let fpsTimer = 0;
  function pulseFPS(){
    function loop(ts){
      frames++;
      if (ts - fpsTimer >= 1000) {
        const fps = Math.min(120, Math.round((frames * 1000) / (ts - fpsTimer)));
        $('#fps').textContent = `${fps} fps`;
        fpsTimer = ts; frames = 0;
      }
      if ($('#statusVal').textContent === 'running') requestAnimationFrame(loop);
    }
    requestAnimationFrame(loop);
  }

  // Scenario collector for integration
  function collectScenario() {
    const ids = ['witness','measurer','tuesday','backward','collector','bird','knows','forget','parade','listener','sleeper'];
    const out = {};
    ids.forEach(id => out[id] = $(`#${id}`).value);
    out.useLLM = useLLM.checked;
    out.apiKey = $('#apiKey').value || null;
    return out;
  }
  window.AgentWorldsUI = { collectScenario };

  // Toast primitive
  let toastTm;
  function toast(msg){
    const el = $('#toast');
    el.textContent = msg;
    el.classList.add('show');
    clearTimeout(toastTm);
    toastTm = setTimeout(() => el.classList.remove('show'), 1400);
  }

  // Accessibility: announce initial theme
  toast('Ready');
})();
